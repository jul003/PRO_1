###### Notice

*This is the official list of **config** authors for copyright purposes.*

*This file is distinct from the CONTRIBUTORS file. See the latter for an
explanation.*

*Names should be added to this file as: `Organization`;
`[Name](web address)` or `Name <email>` for individuals*

*Please keep the list sorted.*

* * *

[Jonas mg](https://github.com/kless)
[Miguel Branco](https://github.com/msbranco)
[Rob Figueiredo](https://github.com/robfig)
[Tom Bruggeman](https://github.com/tmbrggmn)

