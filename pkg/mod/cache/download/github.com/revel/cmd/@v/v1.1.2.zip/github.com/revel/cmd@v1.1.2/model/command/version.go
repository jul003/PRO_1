package command

type (
	Version struct {
		ImportCommand
	}
)
